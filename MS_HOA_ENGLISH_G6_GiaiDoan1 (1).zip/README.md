# MS HOA ENGLISH - Giai đoạn 1

Website tĩnh HTML/CSS/JavaScript, không cần server/database.

## Chạy thử
Mở `index.html` bằng Chrome.

## Đưa lên GitHub Pages
1. Tạo repository public, ví dụ `ms-hoa-english-grade6`.
2. Upload `index.html`, `style.css`, `script.js`.
3. Settings → Pages.
4. Deploy from branch → `main` → `/root`.
5. Save và chờ GitHub xuất bản.

Lưu ý: Giai đoạn 1 tự chấm trên thiết bị học sinh; kết quả chưa được gửi về giáo viên.
