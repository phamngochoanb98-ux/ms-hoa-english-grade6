const questions = [
  {s:"I",t:"My brother usually ___ breakfast at 7 a.m.",o:["have","has","is having","having"],a:1,l:"Nhận biết"},
  {s:"I",t:"Look! The children ___ football in the playground.",o:["play","plays","are playing","is playing"],a:2,l:"Nhận biết"},
  {s:"I",t:"She ___ to school by bike every day.",o:["go","goes","is going","going"],a:1,l:"Nhận biết"},
  {s:"I",t:"Listen! Someone ___ at the door.",o:["knocks","knock","is knocking","knocking"],a:2,l:"Thông hiểu"},
  {s:"I",t:"We ___ English on Mondays and Wednesdays.",o:["study","studies","are studying","studying"],a:0,l:"Thông hiểu"},
  {s:"I",t:"I ___ my homework right now.",o:["do","does","am doing","doing"],a:2,l:"Thông hiểu"},
  {s:"I",t:"This is ___ book. (Lan)",o:["Lan","Lans","Lan's","Lans'"],a:2,l:"Vận dụng"},
  {s:"I",t:"The computer is ___ the desk.",o:["in","on","at","between"],a:1,l:"Vận dụng"},
  {s:"I",t:"My father ___ coffee every morning.",o:["drink","drinks","is drinking","drinking"],a:1,l:"Vận dụng"},
  {s:"I",t:"Where is Mai? She ___ in her room now.",o:["reads","read","is reading","reading"],a:2,l:"Vận dụng"},
  {s:"I",t:"Every Saturday, Mai ___ to her grandparents, but today she ___ at home.",o:["goes / stays","is going / stays","goes / is staying","is going / is staying"],a:2,l:"Vận dụng cao"},
  {s:"I",t:"Choose the correct sentence.",o:["Nam usually is playing football after school.","Nam usually plays football after school.","Nam plays usually football after school.","Nam is play football after school."],a:1,l:"Vận dụng cao"},

  {s:"II",t:"A place where students study is a ___.",o:["library","school","kitchen","bedroom"],a:1,l:"Nhận biết"},
  {s:"II",t:"We usually sleep in the ___.",o:["living room","bathroom","bedroom","hall"],a:2,l:"Nhận biết"},
  {s:"II",t:"A person who lives near your house is your ___.",o:["classmate","neighbour","teacher","cousin"],a:1,l:"Nhận biết"},
  {s:"II",t:"My best friend is very ___. She always helps me.",o:["helpful","lazy","rude","noisy"],a:0,l:"Thông hiểu"},
  {s:"II",t:"We use a ___ to sit and study at home.",o:["sofa","desk","fridge","sink"],a:1,l:"Thông hiểu"},
  {s:"II",t:"There ___ two bedrooms upstairs.",o:["is","are","am","be"],a:1,l:"Thông hiểu"},
  {s:"II",t:"My house ___ a balcony.",o:["have","has","is having","having"],a:1,l:"Vận dụng"},
  {s:"II",t:"Choose the correct sentence.",o:["There is a books on the table.","There are a book on the table.","There is a book on the table.","There have a book on the table."],a:2,l:"Vận dụng"},
  {s:"II",t:"My friends ___ volleyball now.",o:["play","plays","are playing","is playing"],a:2,l:"Vận dụng"},
  {s:"II",t:"Which word is closest in meaning to 'friendly'?",o:["kind","lazy","strict","quiet"],a:0,l:"Vận dụng"},
  {s:"II",t:"Choose the correct sentence.",o:["My sister are friendly and she help me.","My sister is friendly and she helps me.","My sister is friendly and she is help me.","My sister friendly and helping me."],a:1,l:"Vận dụng cao"},
  {s:"II",t:"Which sentence is grammatically correct?",o:["There are a large kitchen in my house.","There is two bedrooms upstairs.","There is a large kitchen in my house.","There have a large kitchen in my house."],a:2,l:"Vận dụng cao"},

  {s:"III",t:"school / my / is / new / This.",o:["This my is new school.","This is my new school.","My this is new school.","This is new my school."],a:1,l:"Nhận biết"},
  {s:"III",t:"bedroom / is / the / upstairs / My.",o:["My bedroom is upstairs.","Bedroom my is upstairs.","My is bedroom upstairs.","Upstairs is my bedroom."],a:0,l:"Nhận biết"},
  {s:"III",t:"playing / are / children / The / outside.",o:["The children playing are outside.","Are the children playing outside.","The children are playing outside.","Outside the children playing are."],a:2,l:"Thông hiểu"},
  {s:"III",t:"often / I / my / visit / grandparents.",o:["I often visit my grandparents.","I visit often my grandparents.","Often I my grandparents visit.","My grandparents often I visit."],a:0,l:"Thông hiểu"},
  {s:"III",t:"usually / gets / at / Minh / six / up.",o:["Minh gets usually up at six.","Minh usually gets up at six.","Usually Minh gets at six up.","Minh gets up usually six at."],a:1,l:"Vận dụng"},
  {s:"III",t:"now / is / sister / my / cooking / dinner.",o:["My sister cooking is dinner now.","My sister is cooking dinner now.","Now my sister dinner is cooking.","My sister is dinner cooking now."],a:1,l:"Vận dụng"},
  {s:"III",t:"sometimes / with / I / after school / my friends / play / badminton.",o:["I sometimes play badminton with my friends after school.","I play sometimes with my friends badminton after school.","Sometimes play I badminton with my friends after school.","I with my friends sometimes badminton play after school."],a:0,l:"Vận dụng cao"},
  {s:"III",t:"at the moment / our / is / teacher / explaining / the lesson.",o:["Our teacher explaining is the lesson at the moment.","At the moment our teacher the lesson is explaining.","Our teacher is explaining the lesson at the moment.","Our teacher is the lesson explaining at the moment."],a:2,l:"Vận dụng cao"},

  {s:"IV-A",t:"Reading cloze: I ___ in a small house with my parents.",o:["live","lives","am living","living"],a:0,l:"Thông hiểu"},
  {s:"IV-A",t:"Reading cloze: Every morning, I ___ to school at seven.",o:["go","goes","am going","going"],a:0,l:"Thông hiểu"},
  {s:"IV-A",t:"Reading cloze: Today, I ___ at home because I am ill.",o:["stay","stays","am staying","staying"],a:2,l:"Vận dụng"},
  {s:"IV-A",t:"Reading cloze: My sister is in the kitchen. She ___ breakfast.",o:["makes","make","is making","making"],a:2,l:"Vận dụng cao"},
  {s:"IV-B",t:"Linh lives in a house near her school. How does she go to school?",o:["By bus","By bike","On foot","By car"],a:2,l:"Thông hiểu"},
  {s:"IV-B",t:"Where does Linh live?",o:["Near her school","Near a park","In an apartment","With her teacher"],a:0,l:"Thông hiểu"},
  {s:"IV-B",t:"When does Mai often visit Linh?",o:["Every morning","At weekends","On school days","Every evening"],a:1,l:"Vận dụng"},
  {s:"IV-B",t:"Which statement is TRUE?",o:["Linh goes to school by bus.","Linh lives far from school.","Linh often spends weekends with Mai.","Linh never has friends at home."],a:2,l:"Vận dụng cao"}
];

const sectionInfo = {
  "I": ["PHẦN I. GRAMMAR", "Present Simple • Present Continuous • Possessive case • Prepositions"],
  "II": ["PHẦN II. VOCABULARY & GRAMMAR", "Unit 1 • My New School | Unit 2 • My House | Unit 3 • My Friends"],
  "III": ["PHẦN III. SENTENCE ORDERING", "Sắp xếp từ thành câu đúng"],
  "IV-A": ["PHẦN IV.A. READING CLOZE", "Đọc điền từ vào chỗ trống"],
  "IV-B": ["PHẦN IV.B. READING FOR DETAILS", "Đọc hiểu thông tin chi tiết"]
};

let studentName="", studentClass="", timeLeft=3600, timerId=null, submitted=false;

const $ = id => document.getElementById(id);

function renderQuiz(){
  const box=$("quiz"); box.innerHTML="";
  let lastSection="";
  questions.forEach((q,i)=>{
    if(q.s!==lastSection){
      const h=document.createElement("div"); h.className="section-title";
      h.innerHTML=`<h2>${sectionInfo[q.s][0]}</h2><p>${sectionInfo[q.s][1]}</p>`;
      box.appendChild(h); lastSection=q.s;
    }
    const card=document.createElement("div"); card.className="question";
    card.innerHTML=`<div class="qhead">Câu ${i+1}. ${q.t} <span class="level">${q.l}</span></div>`;
    q.o.forEach((opt,j)=>{
      const label=document.createElement("label"); label.className="option";
      label.innerHTML=`<input type="radio" name="q${i}" value="${j}"> ${String.fromCharCode(65+j)}. ${opt}`;
      card.appendChild(label);
    });
    box.appendChild(card);
  });
  document.querySelectorAll('input[type=radio]').forEach(x=>x.addEventListener("change",updateProgress));
}

function updateProgress(){
  let n=0; questions.forEach((_,i)=>{if(document.querySelector(`input[name="q${i}"]:checked`))n++});
  $("progressText").textContent=`${n}/${questions.length} câu`;
}

function startTimer(){
  clearInterval(timerId);
  timeLeft=3600; drawTimer();
  timerId=setInterval(()=>{
    timeLeft--; drawTimer();
    if(timeLeft<=0){clearInterval(timerId); alert("Đã hết 60 phút. Bài sẽ được nộp tự động."); submitQuiz(true);}
  },1000);
}
function drawTimer(){
  const m=String(Math.floor(timeLeft/60)).padStart(2,"0");
  const s=String(timeLeft%60).padStart(2,"0");
  $("timer").textContent=`${m}:${s}`;
  $("timer").classList.toggle("warning",timeLeft<=300);
}
function submitQuiz(auto=false){
  if(submitted)return;
  let answered=0, correct=0, unanswered=[];
  questions.forEach((q,i)=>{
    const x=document.querySelector(`input[name="q${i}"]:checked`);
    if(x){answered++; if(Number(x.value)===q.a)correct++}
    else unanswered.push(i+1);
  });
  if(!auto && unanswered.length){
    const go=confirm(`Em còn ${unanswered.length} câu chưa làm. Em có chắc muốn nộp bài không?`);
    if(!go)return;
  }
  submitted=true; clearInterval(timerId);
  const score=(correct/40*10).toFixed(1);
  $("resultStudent").innerHTML=`<b>${escapeHtml(studentName)}</b> • Lớp ${escapeHtml(studentClass)}`;
  $("score").textContent=`${score}/10`;
  $("resultSummary").textContent=`Đúng ${correct}/40 câu • ${Math.round(correct/40*100)}% • Bài đã được nộp trên thiết bị này.`;
  $("quizScreen").hidden=true; $("result").hidden=false;
  window.scrollTo({top:0,behavior:"smooth"});
  localStorage.setItem("msHoaLastResult",JSON.stringify({studentName,studentClass,correct,score,date:new Date().toLocaleString("vi-VN")}));
}
function showReview(){
  const box=$("review"); box.hidden=!box.hidden;
  if(box.hidden)return;
  box.innerHTML="<h3>Đáp án & kết quả từng câu</h3>";
  questions.forEach((q,i)=>{
    const x=document.querySelector(`input[name="q${i}"]:checked`);
    const chosen=x?Number(x.value):-1, ok=chosen===q.a;
    const div=document.createElement("div"); div.className=`review-item ${ok?"ok":"bad"}`;
    div.innerHTML=`<b>Câu ${i+1}</b>: ${ok?"✓ Đúng":"✗ Chưa đúng"}<br>
      Đáp án đúng: <b>${String.fromCharCode(65+q.a)}. ${escapeHtml(q.o[q.a])}</b>
      ${chosen>=0&&!ok?`<br>Em chọn: ${String.fromCharCode(65+chosen)}. ${escapeHtml(q.o[chosen])}`:""}`;
    box.appendChild(div);
  });
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

$("startBtn").onclick=()=>{
  studentName=$("name").value.trim(); studentClass=$("className").value.trim();
  if(!studentName||!studentClass){alert("Vui lòng nhập họ tên và lớp.");return}
  $("start").hidden=true; $("quizScreen").hidden=false; renderQuiz(); startTimer(); window.scrollTo({top:0,behavior:"smooth"});
};
$("submitBtn").onclick=()=>submitQuiz(false);
$("reviewBtn").onclick=showReview;
$("againBtn").onclick=()=>location.reload();
